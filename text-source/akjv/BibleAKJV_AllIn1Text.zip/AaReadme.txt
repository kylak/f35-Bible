      Introduction to the American King James Version (AKJV) Bible

  AKJV - The American KJV, the EXACT SAME TRANSLATION as the KJV, but with modernized word-endings.
  AV - Authorized Version, of 1611 (another name for the KJV).
  KJV - King James Version, of 1611; also sometimes called the Authorized Version.
  Majority Text - the vast majority of ancient Greek Scripture fragments; consistent with the KJV source texts.
  RT - Received Text i.e. the English, for the Latin name: TR - Textus Receptus.
  TR - Textus Receptus (a.k.a. Received Text); the 5000+ Scripture portions preserved by the saints; i.e. the Greek underlying the KJV.
  Westcott & Hort - Two non-Christians of the late 19th Century who made a corrupted Greek text from a few scrolls preserved by the "scholars"; i.e. the corrupted Greek underlying most modern translations.


This translation/update is in the Public Domain, so feel free to copy, publish, and use it. No permission in whatsoever form is needed. You already have 100% permission to publish, copy, and distribute the American King James Version (AKJV) as much as you want to in any form. 

The AKJV Bible is in the Public Domain.

Lord Bless You,   Paul Abramson,  Editor of: www.creationism.org
  
From:  www.creationism.org/BibleAKJV/

    (The full 66 books of the Bible 
    are available for the AKJV in: 
    HTML format & in text (UTF-8), 
    within ZIP files, per above.) 
  
  